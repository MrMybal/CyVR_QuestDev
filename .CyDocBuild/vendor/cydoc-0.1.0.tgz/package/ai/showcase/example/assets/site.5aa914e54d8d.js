// Standalone CyDoc showcase reference. MIT licensed.
(() => {
const copy = {
  en: {
    'meta.title': 'CyDoc — Documentation, part of your application.',
    'meta.description': 'Write with CyDoc Studio. Ship a local, multilingual manual with rich media, contextual help and an independent reader. Open source, MIT licensed.',
    'skip': 'Skip to content', 'nav.features': 'Explore', 'nav.docs': 'Documentation', 'nav.download': 'Download', 'nav.menu': 'Open navigation', 'nav.language': 'Language',
    'hero.status': 'In development · Studio 0.1.2', 'hero.title': 'CyDoc',
    'hero.lead': 'Good documentation. Right inside your app.',
    'hero.body': 'Write, illustrate and publish your manuals with Studio. Give your users a clear, searchable reader that works from local files.',
    'hero.download': 'Get Studio for Windows', 'hero.reader': 'Try the reader', 'hero.note': 'Windows x64 editor · Web editor · MIT license',
    'hero.caption': 'CyDoc Studio · Visual editor, page tree and properties',
    'hero.alt': 'CyDoc Studio editing the example manual, with page navigation, a visual editor and page properties.',
    'strip.write': 'Write in Studio', 'strip.ship': 'Ship with your app', 'strip.read': 'Read without a server',
    'chapter.label': 'Page chapters', 'chapter.editor': 'Studio', 'chapter.reader': 'Reader', 'chapter.media': 'Media', 'chapter.graphs': 'Diagrams & graphs', 'chapter.api': 'API & links', 'chapter.appearance': 'Themes', 'chapter.workflow': 'Your workflow', 'chapter.download': 'Get started',
    'intro.kicker': 'FOR THE PEOPLE USING YOUR SOFTWARE', 'intro.title': 'From the first explanation to the right answer.',
    'intro.body': 'For application developers, plugin authors and teams who want their manuals to travel with their software. CyDoc brings authoring, rich content and contextual help together, while keeping the reader independent.',
    'intro.editor.title': 'An editor for authors', 'intro.editor.body': 'Visual or Markdown writing, a page tree and a real reader preview. Work in a local folder or a shared online project.',
    'intro.reader.title': 'A manual for people', 'intro.reader.body': 'Search, a clear hierarchy, illustrations and stable links. Open Documentation.html and start reading.',
    'intro.library.title': 'A library for your app', 'intro.library.body': 'A DOM-free core and optional viewers. Include the modules your manual needs, and keep help links close to each feature.',
    'editor.kicker': '01 / CYDOC STUDIO', 'editor.title': 'Write the way you think.',
    'editor.body': 'Draft visually, switch to Markdown for precise control, and keep the same page. Organize chapters in the tree, adjust page properties and let autosave record your changes.',
    'editor.item1': 'Headings, tables, lists, links and code blocks', 'editor.item2': 'Stable page IDs, descriptions, parents and order', 'editor.item3': 'Working revision history and external-file conflict handling', 'editor.link': 'Explore the editor guide',
    'editor.caption': 'Markdown mode · The same page, with its original syntax', 'editor.alt': 'Studio Markdown editor showing explicit anchors and documentation links beside the page properties.',
    'author.media.title': 'Keep illustrations close.', 'author.media.body': 'Import local images, GIFs, videos and models through the media library. Configure advanced media, diagrams and graph blocks with CyDoc JSON or Markdown.',
    'author.media.caption': 'Media library · Local assets from the editable example', 'author.media.alt': 'Studio media library listing local images, GIFs, videos and GLB models.',
    'author.languages.title': 'English and French, together.', 'author.languages.body': 'Write the English original, then complete and review its French translation. Shared IDs preserve links. Changing the original marks the translation outdated; incomplete publication is blocked.',
    'author.languages.caption': 'French page · Localized interface and translation review', 'author.languages.alt': 'French CyDoc Studio interface editing the translated writing guide, with its translation review controls.',
    'reader.kicker': '02 / THE READER', 'reader.title': 'Help that stays within reach.',
    'reader.body': 'Ship the complete manual beside your application. Open it directly through file://, embed it in a dedicated WebView, or serve the same export on a static website.',
    'reader.item1': 'Nested navigation and a page outline', 'reader.item2': 'Local search across text, code and symbols', 'reader.item3': 'Bookmarks, private notes and remembered reading positions', 'reader.link': 'Open the live manual',
    'reader.caption': 'The real CyDoc reader · A guide with navigation and a page outline', 'reader.alt': 'CyDoc Quickstart reader showing its page tree, code examples and table of contents.',
    'search.title': 'Find the term. Keep the context.', 'search.body': 'Search from the header or press Ctrl+K. Filter by content type and code language, then jump to the relevant page or section. Search stays local to the manual.',
    'search.caption': 'Local search · Results for “mesh” in the example manual', 'search.alt': 'CyDoc local search showing matching guides, API and media pages for mesh.',
    'media.kicker': '03 / OPTIONAL MEDIA MODULES', 'media.title': 'Show what words cannot.',
    'media.body': 'Explain a setting with an image. Compare a change. Annotate a moment or inspect a model. Every viewer is optional, and enlargement stays inside the documentation window.',
    'media.tabs': 'Explore the media viewers', 'media.image': 'Images', 'media.video': 'Video', 'media.gif': 'GIF', 'media.mesh': '3D models', 'media.gallery': 'Galleries', 'media.graph': 'Node graphs', 'media.pbr': 'PBR', 'media.wire': 'Wireframe',
    'media.image.title': 'Inspect. Annotate. Compare.', 'media.image.body': 'Zoom, pan, draw arrows or areas, and compare two images with a draggable divider. A/B transforms remain synchronized.',
    'media.video.title': 'Put the explanation at the right moment.', 'media.video.body': 'Timed and positioned annotations, playback speed, frame stepping and synchronized A/B playback. Supply codec variants supported by your users’ browsers.',
    'media.gif.title': 'More than an animation.', 'media.gif.body': 'Autoplay when appropriate, or pause, scrub and step through a GIF. Compare two animations on a shared timeline.',
    'media.mesh.title': 'A closer look at the model.', 'media.mesh.body': 'Inspect GLB/glTF with PBR materials, lighting presets, scene selection, annotations, wireframe and saved camera views. Compare models with a shared camera.',
    'media.gallery.title': 'Several views. One place.', 'media.gallery.body': 'Group images, videos, GIFs and models into a gallery, including mixed collections. Only the active item’s viewer is mounted.',
    'media.graph.title': 'Make the connections readable.', 'media.graph.body': 'Typed ports, curved connections, comment groups and links into the manual. Pan, zoom and inspect a node’s purpose.',
    'media.example': 'Try this example in the reader', 'media.caption': 'Actual viewer capture from the CyDoc example', 'media.limit': 'Video decoding depends on the browser. The mesh viewer requires WebGL 2; Three.js is loaded only for that module.',
    'modules.title': 'Choose what you ship.', 'modules.body': 'Enable image, video, GIF, mesh, gallery and graph readers independently. The core has no runtime dependencies and does not import a media engine.',
    'modules.caption': 'Project settings · Select the optional readers', 'modules.alt': 'Studio project settings showing the six optional media modules.',
    'graphs.kicker': '04 / EXPLAIN THE STRUCTURE', 'graphs.title': 'From a workflow to a graph.',
    'graphs.body': 'Turn flows, decisions, sequences, classes, dependencies and architectures into SVG diagrams at build time. For interactive content, use the separate node graph viewer with typed ports and documentation links.',
    'graphs.blueprint': 'The graph viewer also reads a subset of Unreal Blueprint clipboard text. It displays the graph; it does not execute Blueprints or open binary .uasset files.',
    'graphs.diagram.caption': 'Diagram gallery · A decision flow compiled to SVG', 'graphs.diagram.alt': 'CyDoc reader showing a real decision flow diagram from its example manual.',
    'graphs.graph.caption': 'Interactive node graph · From F1 to contextual help', 'graphs.graph.alt': 'CyDoc node graph viewer showing an F1 event connected to a help-link function and a documentation opener.',
    'graphs.link': 'Explore diagrams and graphs',
    'api.kicker': '05 / CONNECT YOUR CODE AND YOUR MANUAL', 'api.title': 'One click. The right explanation.',
    'api.body': 'Open the relevant page and section from your app, including contextual F1 help. Stable links can also target annotations, video times, code lines, graph nodes and saved 3D views.',
    'api.extract': 'Keep reference material close to the code: extract annotated comments and Python docstrings, or import Doxygen XML, TypeDoc JSON and neutral API data. Publish signatures, parameters, includes and modules, without raw implementation listings.',
    'api.languages': 'Build-time highlighting: C++, Python, HLSL, GLSL, C#, C, JavaScript, Java and TypeScript.',
    'api.caption': 'Structured API · Linked classes, inheritance and members', 'api.alt': 'CyDoc reference page for the example C++ HelpSession class, showing its signature and linked API members.', 'api.link': 'See API and integration examples', 'api.code': 'A contextual link from JavaScript', 'api.comment': '// CyDoc · contextual help',
    'theme.kicker': '06 / APPEARANCE', 'theme.title': 'The same manual. A different light.',
    'theme.body': 'Light, Dark, Midnight, Nord, Paper and High contrast. The reader remembers your choice. Studio shares all six themes across its editor, Windows shell and bundled manual.',
    'theme.help': 'Drag the divider to compare actual Dark and Paper captures.', 'theme.range': 'Compare Dark and Paper themes', 'theme.dark': 'Dark', 'theme.paper': 'Paper', 'theme.alt': 'The same CyDoc rich-content page captured in Dark and Paper themes.',
    'workflow.kicker': '07 / YOUR WORKFLOW', 'workflow.title': 'A folder today. A team tomorrow.',
    'workflow.local.title': 'Local. Without an account.', 'workflow.local.body': 'Open Studio on Windows and start writing. Ordinary folder projects need neither a login nor Git. The browser editor also has a loopback-only local mode.',
    'workflow.team.title': 'Shared when you need it.', 'workflow.team.body': 'Host the editor with accounts, invitations, owner/editor/viewer roles, live presence and simultaneous Yjs editing. Online authoring needs persistent storage, HTTPS and WebSockets on a single server.',
    'workflow.git.title': 'Git stays optional.', 'workflow.git.body': 'Review diffs, commit documentation, browse history and work with branches. Supported HTTPS remotes are GitHub, GitLab and Bitbucket. Publishing a manual does not push Git.',
    'workflow.git.caption': 'Git panel · Documentation changes in the isolated example project', 'workflow.git.alt': 'Studio Git panel showing a local documentation change and the available repository actions.',
    'workflow.automation.title': 'A local SDK, too.', 'workflow.automation.body': 'Use JavaScript or Python SDKs and 22 CyToolsCore MCP operations to create projects, edit pages, import media and publish. Revision checks protect concurrent changes. Assistant guidance stays in the separate DocAI.md sidecar.', 'workflow.automation.link': 'Explore Studio integrations',
    'desktop.title': 'A Windows workspace for your manuals.', 'desktop.body': 'The portable CyUI/CEF application brings the editor, documentation, options and local MCP / SDK into full-window tabs. Its reader has a retained view, so returning to the editor keeps your working page.', 'desktop.caption': 'Windows application · The bundled manual in its own tab', 'desktop.alt': 'The actual Windows CyDoc Studio application displaying its bundled manual with Editor, Documentation, Options and Local MCP / SDK tabs.',
    'download.kicker': 'START WITH YOUR NEXT MANUAL', 'download.title': 'Make your documentation part of the app.',
    'download.body': 'Try the editable CyDoc example, or bring your own application. Build a manual people can explore, even without an internet connection.',
    'download.windows': 'Download Studio 0.1.2', 'download.source': 'Browse the source', 'download.checksum': 'SHA-256 checksums', 'download.note': 'Portable Windows x64 ZIP · MIT license · Development release',
    'download.web': 'Prefer the browser? Run or self-host the editor from source. The exported reader can be hosted statically.', 'download.web.link': 'Browser editor guide',
    'faq.title': 'Before you start.', 'faq.q1': 'What is available today?', 'faq.a1': 'Studio 0.1.2 is available as a portable Windows x64 release. The reader library is version 0.1.0 and is not on npm yet. Both are in early development. This is not a stable 1.0 release.',
    'faq.q2': 'Does the documentation need a server?', 'faq.a2': 'No. Published manuals open through Documentation.html directly from local files. Keep the complete DocData folder beside it. The same export can be hosted on a static server. Editing and online collaboration use a separate Studio service.',
    'faq.q3': 'Which platforms are supported?', 'faq.a3': 'The downloadable native Studio editor is Windows x64 only. The browser editor runs through its Node.js service. The reader targets modern browsers and WebViews; native integration examples cover Windows, Linux, macOS and Android, with target-device validation still required.',
    'faq.q4': 'Can I work without a login or Git?', 'faq.a4': 'Yes. Windows starts in account-free local mode. Start the browser service with --local for the same workflow. Folder projects work without Git. Accounts and invitations are used by the separately hosted online mode.',
    'faq.q5': 'What should I know about this first release?', 'faq.a5': 'The portable Windows executables are not code-signed, and the current CyUI Python CEF bridge runs without the CEF process sandbox. Use trusted documentation projects. Advanced rich blocks use JSON/Markdown configuration. There are no native Linux/macOS editor builds or multi-server collaboration yet.',
    'footer.line': 'Documentation for people. Tools for authors.', 'footer.license': 'MIT license', 'footer.releases': 'Releases', 'footer.source': 'Source code',
    'lightbox.close': 'Close image', 'lightbox.previous': 'Previous image', 'lightbox.next': 'Next image', 'lightbox.help': 'Escape to close · Arrow keys to browse', 'lightbox.open': 'Enlarge screenshot',
  },
  fr: {
    'meta.title': 'CyDoc — La documentation fait partie de votre application.',
    'meta.description': 'Rédigez avec CyDoc Studio. Distribuez un manuel local et multilingue avec médias enrichis, aide contextuelle et lecteur indépendant. Open source, sous licence MIT.',
    'skip': 'Aller au contenu', 'nav.features': 'Découvrir', 'nav.docs': 'Documentation', 'nav.download': 'Télécharger', 'nav.menu': 'Ouvrir la navigation', 'nav.language': 'Langue',
    'hero.status': 'En développement · Studio 0.1.2', 'hero.title': 'CyDoc',
    'hero.lead': 'Une documentation claire. Dans votre application.',
    'hero.body': 'Rédigez, illustrez et publiez vos manuels avec Studio. Offrez à vos utilisateurs un lecteur clair, avec recherche, qui fonctionne depuis des fichiers locaux.',
    'hero.download': 'Studio pour Windows', 'hero.reader': 'Essayer le lecteur', 'hero.note': 'Éditeur Windows x64 · Éditeur web · Licence MIT',
    'hero.caption': 'CyDoc Studio · Éditeur visuel, arborescence et propriétés',
    'hero.alt': 'CyDoc Studio modifiant le manuel d’exemple, avec navigation, éditeur visuel et propriétés de la page.',
    'strip.write': 'Rédiger dans Studio', 'strip.ship': 'Distribuer avec votre app', 'strip.read': 'Lire sans serveur',
    'chapter.label': 'Chapitres de la page', 'chapter.editor': 'Studio', 'chapter.reader': 'Lecteur', 'chapter.media': 'Médias', 'chapter.graphs': 'Schémas et graphes', 'chapter.api': 'API et liens', 'chapter.appearance': 'Thèmes', 'chapter.workflow': 'Votre méthode', 'chapter.download': 'Commencer',
    'intro.kicker': 'POUR LES PERSONNES QUI UTILISENT VOTRE LOGICIEL', 'intro.title': 'De la première explication à la bonne réponse.',
    'intro.body': 'Pour les développeurs d’applications, les auteurs de plugins et les équipes qui veulent distribuer leurs manuels avec leurs logiciels. CyDoc réunit rédaction, contenu enrichi et aide contextuelle, tout en gardant un lecteur indépendant.',
    'intro.editor.title': 'Un éditeur pour rédiger', 'intro.editor.body': 'Édition visuelle ou Markdown, arborescence et aperçu dans le vrai lecteur. Travaillez dans un dossier local ou un projet partagé en ligne.',
    'intro.reader.title': 'Un manuel pour les humains', 'intro.reader.body': 'Recherche, hiérarchie claire, illustrations et liens stables. Ouvrez Documentation.html et commencez la lecture.',
    'intro.library.title': 'Une bibliothèque pour votre app', 'intro.library.body': 'Un noyau indépendant du DOM et des lecteurs facultatifs. Ajoutez les modules utiles et placez les liens d’aide au plus près des fonctionnalités.',
    'editor.kicker': '01 / CYDOC STUDIO', 'editor.title': 'Écrivez à votre façon.',
    'editor.body': 'Rédigez visuellement, passez à Markdown pour un contrôle précis et conservez la même page. Organisez les chapitres dans l’arborescence, ajustez leurs propriétés et laissez l’enregistrement automatique conserver vos changements.',
    'editor.item1': 'Titres, tableaux, listes, liens et blocs de code', 'editor.item2': 'Identifiants stables, descriptions, parents et ordre', 'editor.item3': 'Historique de travail et gestion des conflits avec les fichiers externes', 'editor.link': 'Découvrir le guide de l’éditeur',
    'editor.caption': 'Mode Markdown · La même page, dans sa syntaxe originale', 'editor.alt': 'Éditeur Markdown de Studio avec ancres explicites, liens de documentation et propriétés de la page.',
    'author.media.title': 'Gardez vos illustrations à portée de main.', 'author.media.body': 'Importez images, GIF, vidéos et modèles locaux avec la médiathèque. Configurez les médias avancés, schémas et graphes avec les blocs JSON ou Markdown de CyDoc.',
    'author.media.caption': 'Médiathèque · Fichiers locaux de l’exemple modifiable', 'author.media.alt': 'Médiathèque de Studio listant les images, GIF, vidéos et modèles GLB locaux.',
    'author.languages.title': 'L’anglais et le français, ensemble.', 'author.languages.body': 'Rédigez l’original anglais, puis complétez et relisez sa traduction française. Les identifiants communs préservent les liens. Modifier l’original rend la traduction obsolète ; une publication incomplète est bloquée.',
    'author.languages.caption': 'Page française · Interface traduite et relecture de la traduction', 'author.languages.alt': 'Interface française de CyDoc Studio modifiant le guide de rédaction traduit, avec les contrôles de relecture.',
    'reader.kicker': '02 / LE LECTEUR', 'reader.title': 'L’aide reste à portée de main.',
    'reader.body': 'Distribuez le manuel complet avec votre application. Ouvrez-le directement avec file://, intégrez-le dans une WebView dédiée ou hébergez le même export sur un site statique.',
    'reader.item1': 'Navigation arborescente et sommaire de la page', 'reader.item2': 'Recherche locale dans les textes, le code et les symboles', 'reader.item3': 'Favoris, notes privées et positions de lecture conservées', 'reader.link': 'Ouvrir le vrai manuel',
    'reader.caption': 'Le vrai lecteur CyDoc · Un guide avec navigation et sommaire', 'reader.alt': 'Guide de démarrage de CyDoc avec son arborescence, ses exemples de code et son sommaire.',
    'search.title': 'Trouvez le terme. Gardez le contexte.', 'search.body': 'Cherchez dans l’en-tête ou appuyez sur Ctrl+K. Filtrez par type de contenu et langage, puis rejoignez la page ou la section pertinente. La recherche reste locale au manuel.',
    'search.caption': 'Recherche locale · Résultats pour « mesh » dans le manuel d’exemple', 'search.alt': 'Recherche locale de CyDoc montrant les guides, API et médias correspondant au terme mesh.',
    'media.kicker': '03 / MODULES MÉDIAS FACULTATIFS', 'media.title': 'Montrez ce que les mots ne suffisent pas à expliquer.',
    'media.body': 'Illustrez un réglage. Comparez un changement. Annotez un instant ou inspectez un modèle. Chaque lecteur est facultatif et l’agrandissement reste dans la fenêtre de documentation.',
    'media.tabs': 'Explorer les lecteurs de médias', 'media.image': 'Images', 'media.video': 'Vidéo', 'media.gif': 'GIF', 'media.mesh': 'Modèles 3D', 'media.gallery': 'Galeries', 'media.graph': 'Graphes à nœuds', 'media.pbr': 'PBR', 'media.wire': 'Maillage',
    'media.image.title': 'Inspectez. Annotez. Comparez.', 'media.image.body': 'Zoomez, déplacez-vous, tracez des flèches ou des zones et comparez deux images avec un séparateur déplaçable. Les transformations A/B restent synchronisées.',
    'media.video.title': 'Placez l’explication au bon moment.', 'media.video.body': 'Annotations temporelles et positionnées, vitesse de lecture, avance par image et lecture A/B synchronisée. Fournissez des variantes de codecs compatibles avec les navigateurs de vos utilisateurs.',
    'media.gif.title': 'Plus qu’une animation.', 'media.gif.body': 'Lancez automatiquement si nécessaire, ou mettez en pause, parcourez et avancez image par image dans un GIF. Comparez deux animations sur une même ligne temporelle.',
    'media.mesh.title': 'Regardez le modèle de plus près.', 'media.mesh.body': 'Inspectez des GLB/glTF avec matériaux PBR, éclairages, choix de scène, annotations, maillage et vues enregistrées. Comparez les modèles avec une caméra commune.',
    'media.gallery.title': 'Plusieurs vues. Un seul endroit.', 'media.gallery.body': 'Regroupez images, vidéos, GIF et modèles dans une galerie, y compris dans une collection mixte. Seul le lecteur de l’élément actif est monté.',
    'media.graph.title': 'Rendez les connexions lisibles.', 'media.graph.body': 'Ports typés, connexions courbes, groupes de commentaires et liens vers le manuel. Déplacez-vous, zoomez et examinez le rôle d’un nœud.',
    'media.example': 'Essayer cet exemple dans le lecteur', 'media.caption': 'Capture réelle d’un lecteur de l’exemple CyDoc', 'media.limit': 'Le décodage vidéo dépend du navigateur. Le lecteur de mesh nécessite WebGL 2 ; Three.js est chargé uniquement pour ce module.',
    'modules.title': 'Choisissez ce que vous distribuez.', 'modules.body': 'Activez séparément les lecteurs image, vidéo, GIF, mesh, galerie et graphe. Le noyau n’a aucune dépendance à l’exécution et n’importe aucun moteur de médias.',
    'modules.caption': 'Paramètres du projet · Choix des lecteurs facultatifs', 'modules.alt': 'Paramètres de Studio montrant les six modules de médias facultatifs.',
    'graphs.kicker': '04 / EXPLIQUER LA STRUCTURE', 'graphs.title': 'Du parcours au graphe.',
    'graphs.body': 'Transformez flux, décisions, séquences, classes, dépendances et architectures en schémas SVG lors de la génération. Pour le contenu interactif, utilisez le lecteur de graphes à nœuds avec ports typés et liens de documentation.',
    'graphs.blueprint': 'Le lecteur de graphes lit aussi un sous-ensemble du texte copié depuis Unreal Blueprint. Il affiche le graphe ; il n’exécute pas les Blueprints et n’ouvre pas les fichiers binaires .uasset.',
    'graphs.diagram.caption': 'Galerie de schémas · Un flux de décision compilé en SVG', 'graphs.diagram.alt': 'Lecteur CyDoc affichant un vrai schéma de décision du manuel d’exemple.',
    'graphs.graph.caption': 'Graphe interactif · De F1 à l’aide contextuelle', 'graphs.graph.alt': 'Lecteur de graphes CyDoc avec un événement F1 relié à la création d’un lien d’aide et à l’ouverture de la documentation.',
    'graphs.link': 'Explorer les schémas et les graphes',
    'api.kicker': '05 / RELIER LE CODE ET LE MANUEL', 'api.title': 'Un clic. La bonne explication.',
    'api.body': 'Ouvrez la page et la section utiles depuis votre application, y compris avec l’aide contextuelle F1. Les liens stables peuvent aussi cibler annotations, instants vidéo, lignes de code, nœuds et vues 3D enregistrées.',
    'api.extract': 'Gardez les références près du code : extrayez les commentaires annotés et docstrings Python, ou importez du XML Doxygen, du JSON TypeDoc et des données API neutres. Publiez signatures, paramètres, includes et modules, sans lister les implémentations brutes.',
    'api.languages': 'Coloration à la génération : C++, Python, HLSL, GLSL, C#, C, JavaScript, Java et TypeScript.',
    'api.caption': 'API structurée · Classes, héritage et membres liés', 'api.alt': 'Référence CyDoc de la classe C++ d’exemple HelpSession, avec sa signature et ses membres liés.', 'api.link': 'Voir les exemples d’API et d’intégration', 'api.code': 'Un lien contextuel depuis JavaScript', 'api.comment': '// CyDoc · aide contextuelle',
    'theme.kicker': '06 / APPARENCE', 'theme.title': 'Le même manuel. Une autre lumière.',
    'theme.body': 'Clair, Sombre, Minuit, Nord, Papier et Contraste élevé. Le lecteur conserve votre choix. Studio partage ces six thèmes entre l’éditeur, l’interface Windows et le manuel intégré.',
    'theme.help': 'Déplacez le séparateur pour comparer les vraies captures Sombre et Papier.', 'theme.range': 'Comparer les thèmes Sombre et Papier', 'theme.dark': 'Sombre', 'theme.paper': 'Papier', 'theme.alt': 'La même page de contenu enrichi CyDoc capturée avec les thèmes Sombre et Papier.',
    'workflow.kicker': '07 / VOTRE MÉTHODE', 'workflow.title': 'Un dossier aujourd’hui. Une équipe demain.',
    'workflow.local.title': 'En local. Sans compte.', 'workflow.local.body': 'Ouvrez Studio sous Windows et commencez à écrire. Un projet dans un dossier ne demande ni connexion ni Git. L’éditeur dans le navigateur possède aussi un mode local limité à la machine.',
    'workflow.team.title': 'Partagez quand vous en avez besoin.', 'workflow.team.body': 'Hébergez l’éditeur avec comptes, invitations, rôles propriétaire/éditeur/lecteur, présence et édition simultanée avec Yjs. L’édition en ligne nécessite un stockage persistant, HTTPS et WebSocket sur un seul serveur.',
    'workflow.git.title': 'Git reste facultatif.', 'workflow.git.body': 'Relisez les différences, commitez la documentation, parcourez l’historique et utilisez des branches. Les dépôts HTTPS pris en charge sont GitHub, GitLab et Bitbucket. Publier un manuel ne pousse pas Git.',
    'workflow.git.caption': 'Panneau Git · Changements de documentation dans le projet d’exemple isolé', 'workflow.git.alt': 'Panneau Git de Studio avec un changement local de documentation et les actions disponibles sur le dépôt.',
    'workflow.automation.title': 'Un SDK local, aussi.', 'workflow.automation.body': 'Utilisez les SDK JavaScript ou Python et 22 opérations MCP CyToolsCore pour créer des projets, modifier des pages, importer des médias et publier. Les révisions protègent les modifications concurrentes. Les consignes pour les assistants restent dans le fichier séparé DocAI.md.', 'workflow.automation.link': 'Découvrir les intégrations Studio',
    'desktop.title': 'Un espace Windows pour vos manuels.', 'desktop.body': 'L’application portable CyUI/CEF réunit éditeur, documentation, options et MCP / SDK local dans des onglets occupant la fenêtre. Le lecteur possède sa propre vue conservée ; revenir à l’éditeur garde votre page de travail.', 'desktop.caption': 'Application Windows · Le manuel intégré dans son propre onglet', 'desktop.alt': 'La véritable application Windows CyDoc Studio affichant son manuel intégré avec les onglets Éditeur, Documentation, Options et MCP / SDK local.',
    'download.kicker': 'COMMENCEZ AVEC VOTRE PROCHAIN MANUEL', 'download.title': 'Faites de la documentation une partie de l’application.',
    'download.body': 'Essayez l’exemple CyDoc modifiable ou apportez votre application. Créez un manuel que chacun peut explorer, même sans connexion internet.',
    'download.windows': 'Télécharger Studio 0.1.2', 'download.source': 'Parcourir les sources', 'download.checksum': 'Empreintes SHA-256', 'download.note': 'ZIP portable Windows x64 · Licence MIT · Version de développement',
    'download.web': 'Vous préférez le navigateur ? Lancez ou hébergez l’éditeur depuis les sources. Le lecteur exporté peut être hébergé statiquement.', 'download.web.link': 'Guide de l’éditeur dans le navigateur',
    'faq.title': 'Avant de commencer.', 'faq.q1': 'Qu’est-ce qui est disponible aujourd’hui ?', 'faq.a1': 'Studio 0.1.2 est disponible en version portable Windows x64. La bibliothèque de lecture est en version 0.1.0 et n’est pas encore sur npm. Les deux sont en développement initial. Ce n’est pas une version stable 1.0.',
    'faq.q2': 'La documentation a-t-elle besoin d’un serveur ?', 'faq.a2': 'Non. Les manuels publiés s’ouvrent avec Documentation.html directement depuis les fichiers locaux. Gardez le dossier DocData complet à côté. Le même export peut être hébergé sur un serveur statique. L’édition et la collaboration en ligne utilisent un service Studio séparé.',
    'faq.q3': 'Quelles plateformes sont prises en charge ?', 'faq.a3': 'L’éditeur Studio natif téléchargeable est réservé à Windows x64. L’éditeur dans le navigateur fonctionne avec son service Node.js. Le lecteur vise les navigateurs et WebViews modernes ; des exemples natifs existent pour Windows, Linux, macOS et Android, avec validation sur les appareils cibles encore nécessaire.',
    'faq.q4': 'Puis-je travailler sans connexion à un compte ni Git ?', 'faq.a4': 'Oui. Windows démarre en mode local sans compte. Lancez le service navigateur avec --local pour le même fonctionnement. Les projets dans un dossier fonctionnent sans Git. Les comptes et invitations servent au mode en ligne hébergé séparément.',
    'faq.q5': 'Que faut-il savoir sur cette première version ?', 'faq.a5': 'Les exécutables Windows portables ne sont pas signés et le pont CEF Python actuel de CyUI fonctionne sans sandbox de processus CEF. Ouvrez des projets de documentation de confiance. Les blocs avancés se configurent en JSON/Markdown. Il n’y a pas encore d’éditeur natif Linux/macOS ni de collaboration sur plusieurs serveurs.',
    'footer.line': 'Des manuels pour les humains. Des outils pour rédiger.', 'footer.license': 'Licence MIT', 'footer.releases': 'Versions', 'footer.source': 'Code source',
    'lightbox.close': 'Fermer l’image', 'lightbox.previous': 'Image précédente', 'lightbox.next': 'Image suivante', 'lightbox.help': 'Échap pour fermer · Flèches pour parcourir', 'lightbox.open': 'Agrandir la capture',
  },
};

// This reference ships the showcase and reader, not application installers or hosting.
Object.assign(copy.en, {
  'meta.title': 'CyDoc — Standalone showcase example',
  'nav.download': 'Local example',
  'hero.status': 'Standalone example · Studio 0.1.2',
  'hero.download': 'Explore the editor',
  'chapter.download': 'Local example',
  'download.kicker': 'EVERYTHING TO EXPLORE, LOCALLY',
  'download.title': 'The showcase. The manual. One folder.',
  'download.body': 'This standalone reference includes the complete CyDoc showcase, real product screenshots and its English/French HTML manual. Explore it directly from your local files.',
  'download.windows': 'Explore Studio’s guide',
  'download.source': 'Open the quick start',
  'download.note': 'Self-contained example · MIT license · Application installers and source hosting are not included',
  'download.web': 'The bundled manual is the actual CyDoc reader, with its local search and media. No server or account is needed to read it.',
  'download.web.link': 'Explore the local manual',
  'footer.releases': 'Editor guide',
  'footer.source': 'Media guide',
});
Object.assign(copy.fr, {
  'meta.title': 'CyDoc — Exemple de vitrine autonome',
  'nav.download': 'Exemple local',
  'hero.status': 'Exemple autonome · Studio 0.1.2',
  'hero.download': 'Découvrir l’éditeur',
  'chapter.download': 'Exemple local',
  'download.kicker': 'TOUT EXPLORER, EN LOCAL',
  'download.title': 'La vitrine. Le manuel. Un seul dossier.',
  'download.body': 'Cette référence autonome contient la vitrine CyDoc complète, de vraies captures du logiciel et son manuel HTML anglais/français. Explorez-la directement depuis vos fichiers locaux.',
  'download.windows': 'Découvrir le guide de Studio',
  'download.source': 'Ouvrir le démarrage rapide',
  'download.note': 'Exemple autonome · Licence MIT · Installateurs du logiciel et hébergement des sources non inclus',
  'download.web': 'Le manuel fourni est le véritable lecteur CyDoc, avec sa recherche et ses médias locaux. Sa lecture ne demande ni serveur ni compte.',
  'download.web.link': 'Explorer le manuel local',
  'footer.releases': 'Guide de l’éditeur',
  'footer.source': 'Guide des médias',
});

const media = [
  { id: 'image', image: 'reader-image', doc: 'media#images' },
  { id: 'video', image: 'reader-video', doc: 'video-viewer#viewer' },
  { id: 'gif', image: 'reader-gif', doc: 'gif-controls' },
  { id: 'mesh', image: 'reader-mesh', doc: 'mesh-viewer#viewer' },
  { id: 'gallery', image: 'reader-gallery', doc: 'galleries#images' },
  { id: 'graph', image: 'reader-graph', doc: 'blueprints#graph' },
];


let language = new URL(location.href).searchParams.get('lang') === 'fr' ? 'fr' : 'en';
let activeMedia = media[0];
const strings = () => copy[language];
const dialog = document.querySelector('#lightbox');
const picture = document.querySelector('#lightbox-image');
const caption = document.querySelector('#lightbox-caption');
let openedBy;
let currentShot = 0;
let shots = [];

function documentationUrl(target) {
  const [page, anchor] = target.split('#');
  return `./manual/Documentation.html#/${language}/${encodeURIComponent(page)}${anchor ? '/' + encodeURIComponent(anchor) : ''}`;
}

function localize() {
  const messages = strings();
  document.documentElement.lang = language;
  document.title = messages['meta.title'];
  document.querySelector('meta[name="description"]').content = messages['meta.description'];
  document.querySelector('meta[property="og:title"]').content = messages['meta.title'];
  document.querySelector('meta[property="og:description"]').content = messages['meta.description'];
  document.querySelectorAll('[data-i18n]').forEach(element => { element.textContent = messages[element.dataset.i18n]; });
  document.querySelectorAll('[data-i18n-label]').forEach(element => { element.setAttribute('aria-label', messages[element.dataset.i18nLabel]); });
  document.querySelectorAll('[data-i18n-alt]').forEach(element => { element.alt = messages[element.dataset.i18nAlt]; });
  document.querySelectorAll('[data-doc]').forEach(element => { element.href = documentationUrl(element.dataset.doc); });
  document.querySelectorAll('[data-lang]').forEach(element => { element.setAttribute('aria-pressed', String(element.dataset.lang === language)); });
  document.querySelector('[data-localized-shot]').src = `./assets/screenshots/studio-visual${language === 'fr' ? '-fr' : ''}.webp`;
  document.querySelectorAll('[data-shot]').forEach(element => { element.setAttribute('aria-label', `${messages['lightbox.open']}: ${messages[element.dataset.caption]}`); });
  queueChapterUpdate();
}

function chooseMedia(item, { focus = false } = {}) {
  activeMedia = item;
  const heading = document.querySelector('#media-title-current');
  const body = document.querySelector('#media-body-current');
  const panel = document.querySelector('#media-panel');
  heading.dataset.i18n = `media.${item.id}.title`;
  body.dataset.i18n = `media.${item.id}.body`;
  panel.setAttribute('aria-labelledby', `media-tab-${item.id}`);
  panel.querySelector('a[data-doc]').dataset.doc = item.doc;
  const image = panel.querySelector('.shot img');
  image.src = `./assets/screenshots/${item.image}.webp`;
  image.dataset.i18nAlt = `media.${item.id}.body`;
  panel.querySelector('[data-shot]').dataset.caption = `media.${item.id}.title`;
  panel.querySelector('figcaption [data-i18n]').dataset.i18n = `media.${item.id}.title`;
  panel.querySelector('.mesh-modes').hidden = item.id !== 'mesh';
  panel.querySelectorAll('[data-mesh-mode]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.meshMode === 'pbr')));
  document.querySelectorAll('[data-media]').forEach(button => {
    const selected = button.dataset.media === item.id;
    button.setAttribute('aria-selected', String(selected));
    button.tabIndex = selected ? 0 : -1;
    if (selected && focus) button.focus();
  });
  localize();
}

function setLanguage(value) {
  language = value === 'fr' ? 'fr' : 'en';
  const url = new URL(location.href);
  url.searchParams.set('lang', language);
  history.replaceState(null, '', url);
  localize();
}

function showShot(index) {
  currentShot = (index + shots.length) % shots.length;
  const target = shots[currentShot];
  const image = target.querySelector('img');
  picture.src = target.dataset.zoomSrc || image.src;
  picture.alt = image?.alt || strings()['theme.alt'];
  caption.textContent = strings()[target.dataset.caption];
  document.querySelector('#lightbox-count').textContent = `${currentShot + 1} / ${shots.length}`;
}

function openShot(target) {
  openedBy = target;
  shots = [...document.querySelectorAll('[data-shot], [data-zoom-src]')].filter(element => element.getClientRects().length);
  showShot(shots.indexOf(target));
  dialog.showModal();
  document.querySelector('[data-lightbox-close]').focus();
}

const menu = document.querySelector('.menu-button');
function closeMenu() {
  menu.setAttribute('aria-expanded', 'false');
  document.querySelector('#primary-nav').dataset.open = 'false';
}
document.addEventListener('click', event => {
  const languageButton = event.target.closest('[data-lang]');
  if (languageButton) setLanguage(languageButton.dataset.lang);
  const shot = event.target.closest('[data-shot], [data-zoom-src]');
  if (shot) openShot(shot);
  const mediaButton = event.target.closest('[data-media]');
  if (mediaButton) chooseMedia(media.find(item => item.id === mediaButton.dataset.media));
  const meshMode = event.target.closest('[data-mesh-mode]');
  if (meshMode && activeMedia.id === 'mesh') {
    document.querySelector('#media-panel .shot img').src = `./assets/screenshots/reader-mesh${meshMode.dataset.meshMode === 'wire' ? '-wire' : ''}.webp`;
    document.querySelectorAll('[data-mesh-mode]').forEach(button => button.setAttribute('aria-pressed', String(button === meshMode)));
  }
  if (event.target.closest('#primary-nav a')) closeMenu();
});
menu.addEventListener('click', () => {
  const expanded = menu.getAttribute('aria-expanded') !== 'true';
  menu.setAttribute('aria-expanded', String(expanded));
  document.querySelector('#primary-nav').dataset.open = String(expanded);
});
document.querySelector('[role="tablist"]').addEventListener('keydown', event => {
  if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
  event.preventDefault();
  let index = media.indexOf(activeMedia);
  if (event.key === 'Home') index = 0;
  else if (event.key === 'End') index = media.length - 1;
  else index = (index + (event.key === 'ArrowRight' ? 1 : -1) + media.length) % media.length;
  chooseMedia(media[index], { focus: true });
});
document.querySelector('[data-lightbox-close]').addEventListener('click', () => dialog.close());
document.querySelector('[data-lightbox-prev]').addEventListener('click', () => showShot(currentShot - 1));
document.querySelector('[data-lightbox-next]').addEventListener('click', () => showShot(currentShot + 1));
dialog.addEventListener('keydown', event => {
  if (event.key === 'Tab') {
    const controls = [...dialog.querySelectorAll('button:not(:disabled)')];
    const index = controls.indexOf(document.activeElement);
    event.preventDefault();
    controls[(index + (event.shiftKey ? -1 : 1) + controls.length) % controls.length]?.focus();
    return;
  }
  if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
    event.preventDefault();
    showShot(currentShot + (event.key === 'ArrowRight' ? 1 : -1));
  }
});
dialog.addEventListener('click', event => {
  if (event.target !== dialog) return;
  const bounds = dialog.getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) dialog.close();
});
dialog.addEventListener('close', () => {
  picture.removeAttribute('src');
  openedBy?.focus({ preventScroll: true });
});
document.addEventListener('keydown', event => { if (event.key === 'Escape' && !dialog.open) closeMenu(); });

const comparison = document.querySelector('.theme-comparison');
const range = document.querySelector('#theme-range');
function updateComparison(value) {
  range.value = String(Math.max(0, Math.min(100, value)));
  comparison.style.setProperty('--split', `${range.value}%`);
}
range.addEventListener('input', () => updateComparison(Number(range.value)));
const divider = document.querySelector('.compare-divider');
let dragging = false;
function dragComparison(event) {
  const rect = comparison.querySelector('.compare-images').getBoundingClientRect();
  updateComparison((event.clientX - rect.left) / rect.width * 100);
}
divider.addEventListener('pointerdown', event => { if (event.button !== 0) return; dragging = true; divider.setPointerCapture(event.pointerId); dragComparison(event); });
divider.addEventListener('pointermove', event => { if (dragging) dragComparison(event); });
for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) divider.addEventListener(type, () => { dragging = false; });

const chapterLinks = [...document.querySelectorAll('[data-chapter]')];
const observedSections = chapterLinks.map(link => document.getElementById(link.dataset.chapter));
let chapterFrame = false;
function updateActiveChapter() {
  chapterFrame = false;
  const threshold = document.querySelector('.site-header').offsetHeight + document.querySelector('.chapters').offsetHeight + 24;
  let active;
  for (const section of observedSections) if (section.getBoundingClientRect().top <= threshold) active = section;
  chapterLinks.forEach(link => {
    if (link.dataset.chapter === active?.id) link.setAttribute('aria-current', 'true');
    else link.removeAttribute('aria-current');
  });
}
function queueChapterUpdate() { if (!chapterFrame) { chapterFrame = true; requestAnimationFrame(updateActiveChapter); } }
window.addEventListener('scroll', queueChapterUpdate, { passive: true });
window.addEventListener('resize', queueChapterUpdate);
window.addEventListener('popstate', () => { language = new URL(location.href).searchParams.get('lang') === 'fr' ? 'fr' : 'en'; localize(); });
localize();
queueChapterUpdate();

})();
